--[[
    "etc_wunschbrett.lua" by Motnahp
		Enables you to post your request to a list where everyone can look in and see if there are 
		items added.
	v0.1 
		- adds commands add, show and delete
		- adds help
		- adds ucmd 

]]--


Extract to your luadch/scripts/ directory

scripts/etc_wunschbrett/t_wunschbrett.tbl
scripts/etc_wunschbrett.lua
scripts/lang/etc_wunschbrett_v0.1.lang.en
scripts/lang/etc_wunschbrett_v0.1.lang.de